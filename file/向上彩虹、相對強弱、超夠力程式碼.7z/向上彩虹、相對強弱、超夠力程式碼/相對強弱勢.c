#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

/*Constants For Uniform_Rand function*/
#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)

#define MAXSTOCKNUM 10
#define MAXSTOCKDAY 500
#define WORKDAY 250.0
#define CLDRDAY 365.0
#define TIMESPLIT 1.0


/* Generate Uniform Random variables*/
double Uniform_Rand(long *idum)
{
	int j = 0;
	long k = 0;
	double temp = 0;
	static long iy=0;
	static long iv[NTAB];

	if (0 >= *idum || !iy){
		if (1 > -(*idum)) *idum=1;
		else *idum = -(*idum);
			for (j=NTAB+7; 0<=j; j--){
				k = (*idum) / IQ;
				*idum = IA * (*idum-k*IQ) - IR * k;
				if (0 > *idum) *idum += IM;
				if (j < NTAB) iv[j] = *idum;
			}
		iy = iv[0];
	}
	k = (*idum) / IQ;
	*idum = IA * (*idum-k*IQ) - IR * k;
	if (0 > *idum) *idum += IM;
	j = iy / NDIV;
	iy = iv[j];
	iv[j] = *idum;
	if ((temp=AM*iy) > RNMX) return (double)RNMX;
	else return temp;
}//End of Uniform_Rand



/*Generate Standard Normal Random variables
  Returns a normally distributed deviate with zero mean and unit variance,
  using Uniform_gen(idum) as the source of uniform deviates.
*/
double StdNormal_Rand(long *idum)
{
//    float gasdev(long *idum);
//    float Uniform_Rnd(long *idum);
    static int iset = 0;
    static double gset = 0;
    double fac=0, rsq=0, v1=0, v2=0;

    if (0>*idum) iset = 0;
    if (0 == iset ){
        do{
            v1 = 2.0 * Uniform_Rand(idum) - 1.0;
            v2 = 2.0 * Uniform_Rand(idum) - 1.0;
            rsq = v1*v1 + v2*v2;
        }while (1.0 <= rsq || 0.0 == rsq);
        fac = sqrt(-2.0 * log(rsq) / rsq);
        gset = v1 * fac;
        iset = 1;
        return v2 * fac;
    }
    else{
        iset = 0;
        return gset;
    }
}//end of StdNormal_Rnd


void Cholesky(double Corr[][MAXSTOCKNUM],double LL[][MAXSTOCKNUM],int StockNum )
{
    int i=0,j=0,k=0;
    for(i=0; i<StockNum; i++){
        double sum1=0;
        for(j=0; j<i; j++)  {sum1 += LL[i][j]*LL[i][j];}
        LL[i][i] = sqrt(Corr[i][i] - sum1);
        for(j=i+1; j<StockNum; j++){
            double sum2 = 0;
            for(k=0; k<i; k++)  {sum2 += LL[j][k]*LL[i][k];}
            LL[j][i] = (Corr[j][i]-sum2) / LL[i][i];
        }
    }
}

//����v����
double PgnOption(long SimuTimes, double TrdDay, double CrtDay, double GRate, double PRate, double RfRate,
    double FaceValue, double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
    double StockVol[MAXSTOCKNUM], double dt,int StockNum, double*** CorrNormRand )
{
	long i=0,j=0,k=0;
	double SPx[MAXSTOCKNUM]={0}, OptRtn=0, AvgRtn=0, IdxRtn=0;
    for(i=0; i<SimuTimes; i++){
        AvgRtn=0,IdxRtn=0;
        for(j=0; j<StockNum; j++){ SPx[j]=StockPx[j]; }
        for(j=0; j<TIMESPLIT; j++){
            for(k=0; k<StockNum; k++){
                SPx[k]=SPx[k]*exp((RfRate-0.5*StockVol[k]*StockVol[k])*dt+StockVol[k]*CorrNormRand[i][j][k]*sqrt(dt));
            }
        }//end of TrdDay
        for(k=0; k<StockNum-1; k++){  AvgRtn+=SPx[k]/StockInitPx[k]-1;  }//find average return
        AvgRtn/=(StockNum-1);
        IdxRtn=SPx[StockNum-1]/StockInitPx[StockNum-1]-1;//index return
        if(AvgRtn>=IdxRtn){ OptRtn+=GRate+(AvgRtn-IdxRtn)*PRate; }//calculate return
        else{ OptRtn+=GRate; }
    }//end of SimuTimes
    OptRtn/=(double)SimuTimes;
    OptRtn=FaceValue*OptRtn/pow(1.0+RfRate,CrtDay/CLDRDAY);
	return OptRtn;
}



//�p���@�Ӫ�Delta
//k�N����k�ӼЪ� k=0,1,2,3,4
double PgnDelta(int k, long SimuTimes, double TrdDay, double CrtDay, double GRate, double PRate, double RfRate,
    double FaceValue, double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
    double StockVol[MAXSTOCKNUM], double dt,int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double StockInitPxNew[MAXSTOCKNUM]={0};
    double deltas=0.001;
    double Tmp1=0,Tmp2=0;
    int i=0;
    for(i=0; i<StockNum; i++) {StockInitPxNew[i]=StockInitPx[i];}

	StockInitPxNew[k]=StockInitPx[k]+deltas;
	Tmp1=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPxNew, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
	StockInitPxNew[k]=StockInitPx[k]-deltas;
	Tmp2=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPxNew, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
	//printf("Tmp1=%f Tmp2=%f \n",Tmp1,Tmp2);
	return (Tmp1-Tmp2)/(2*deltas);
}

//�p���@�Ӫ�Gamma
double PgnGamma(int k, long SimuTimes, double TrdDay, double CrtDay, double GRate, double PRate, double RfRate,
    double FaceValue, double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
    double StockVol[MAXSTOCKNUM], double dt,int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double StockInitPxNew[MAXSTOCKNUM]={0};
    double deltas=0.001, UPx=0, Px=0, DPx=0;
    int i=0;
    for(i=0;i<StockNum;i++){ StockInitPxNew[i]=StockInitPx[i]; }

	StockInitPxNew[k]=StockInitPx[k]+deltas;
	UPx=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPxNew, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
	StockInitPxNew[k]=StockInitPx[k];
	Px=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPxNew, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
	StockInitPxNew[k]=StockInitPx[k]-deltas;
	DPx=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPxNew, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
	//printf("tmp1=%f tmp2=%f tmp3=%f\n",Tmp1,Tmp2,Tmp3);
	return ((UPx-Px)/deltas-(Px-DPx)/deltas)/deltas;
}

//�p���@�Ӫ�Vega
double PgnVega(int k, long SimuTimes, double TrdDay, double CrtDay, double GRate, double PRate, double RfRate,
    double FaceValue, double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
    double StockVol[MAXSTOCKNUM], double dt,int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double StockVolNew[MAXSTOCKNUM]={0}, deltav=0.01, Tmp1=0,Tmp2=0;
    int i=0;
    for(i=0;i<StockNum;i++) {StockVolNew[i]=StockVol[i];}

	StockVolNew[k]=StockVol[k]+deltav;
	Tmp1=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVolNew, dt, StockNum,CorrNormRand);
	if(0.01>=StockVol[k]){
        double Tmp=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
        return (Tmp1-Tmp)/0.01;
    }
	StockVolNew[k]=StockVol[k]-deltav;
	Tmp2=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVolNew, dt, StockNum,CorrNormRand);

	return (Tmp1-Tmp2)/0.02;
}

//�p���@�Ӫ�Theta
double PgnTheta(long SimuTimes, double TrdDay, double CrtDay, double GRate, double PRate, double RfRate,
    double FaceValue, double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
    double StockVol[MAXSTOCKNUM], double dt,int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double Tmp1=0,Tmp2=0;
	Tmp1=PgnOption(SimuTimes, TrdDay+1, CrtDay+1, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
	Tmp2=PgnOption(SimuTimes, TrdDay-1, CrtDay-1, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
	return (Tmp2-Tmp1)/2.0;
}

//�p��PGN��Rho
double PgnRho(long SimuTimes, double TrdDay, double CrtDay, double GRate, double PRate, double RfRate,
    double FaceValue, double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
    double StockVol[MAXSTOCKNUM], double dt,int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double Tmp1=0, Tmp2=0, DeltaR=0.0001;
	Tmp1=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate+DeltaR, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
	if(0.0001>=RfRate){
        double Tmp=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
        return (Tmp1-Tmp)/DeltaR;
    }
	Tmp2=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate-DeltaR, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
	return (Tmp1-Tmp2)/(2);
}
/*
double BisVega(int k, long SimuTimes, double TrdDay, double CrtDay, double GRate, double PRate, double RfRate,
    double FaceValue, double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
    double StockVol[MAXSTOCKNUM], double dt,int StockNum, double*** CorrNormRand )
{
    double StockVolNew[MAXSTOCKNUM] = {0};
    double Tmp1=0,Tmp2=0;

	StockVolNew[k]=StockVol[k]*1.01;
	Tmp1=PgnOption(N1, N2, SimuTimes, R1, R2, RfRate, LRange, RRange, FaceValue, StockInitPx,StockInitPx, StockVolNew, dt, StockNum, CorrNormRand);
	StockVolNew[k]=StockVol[k]*0.99;
	Tmp2=PgnOption(N1, N2, SimuTimes, R1, R2, RfRate, LRange, RRange, FaceValue, StockInitPx,StockInitPx, StockVolNew, dt, StockNum, CorrNormRand);
	return (Tmp1-Tmp2)/2.0;
}
*/

int main()
{
	double delta=0, gamma=0, vega=0, theta=0,rho=0,Rtn=0;//,bisvega=0
	long i=0,j=0,k=0,l=0;

    //Parameters from file
    long SimuTimes=0;
    double TrdDay=0, CrtDay=0;//�����P������
    double GRate=0,PRate=0, RfRate=0;//�O���v �ѻP�v �L�I�Q�v
    double FaceValue=0;
    double StockVol[MAXSTOCKNUM]={0};
    double StockInitPx[MAXSTOCKNUM]={0};
    double Corr[MAXSTOCKNUM][MAXSTOCKNUM]={{0}};
    //other parameters
    double LL[MAXSTOCKNUM][MAXSTOCKNUM]={{0}};
    double dt=0;
    int StockNum=6;
	double NormRand[MAXSTOCKNUM]={0};
	double ***CorrNormRand;
    long RandSeed=0;

	//�q�ɮ�Ū���Ѽ�
	FILE* fp=fopen("PGNData.txt","r");
    fscanf(fp,"%ld",&SimuTimes);
    fscanf(fp,"%lf",&TrdDay);
    fscanf(fp,"%lf",&CrtDay);
    fscanf(fp,"%lf",&GRate);
    fscanf(fp,"%lf",&PRate);
    fscanf(fp,"%lf",&RfRate);
    fscanf(fp,"%lf",&FaceValue);
    for(i=0; i<StockNum; i++){fscanf(fp,"%lf",&StockInitPx[i]);}
    for(i=0; i<StockNum; i++){fscanf(fp,"%lf",&StockVol[i]);}
    for(i=0; i<StockNum; i++){
        for(j=0; j<StockNum; j++){fscanf(fp,"%lf",&Corr[i][j]);}
    }
    fclose(fp);

    Cholesky(Corr,LL,StockNum);
	dt = TrdDay/TIMESPLIT/(double)WORKDAY;

    //�t�m�`�A�üƪ��Ŷ�
	CorrNormRand=(double***)malloc(SimuTimes*sizeof(double**));
    for(i=0; i<SimuTimes; i++){
        CorrNormRand[i]=(double**)malloc((1+TIMESPLIT)*sizeof(double*));
        for(j=0;j<1+TIMESPLIT;j++){
            CorrNormRand[i][j]=(double*)malloc(StockNum*sizeof(double));
            for(k=0;k<StockNum;k++) {CorrNormRand[i][j][k]=0;}
        }
    }

    //�����`�A�ü�
    RandSeed = -1*(unsigned)time(NULL);
    for(i=0; i<SimuTimes; i++){
        for(j=0; j<TIMESPLIT+1; j++){
            for(k=0; k<StockNum; k++)	{NormRand[k]=StdNormal_Rand(&RandSeed);}//for k
            for(k=0; k<StockNum; k++){
                for(l=0; l<=k; l++)		{CorrNormRand[i][j][k] += LL[k][l]*NormRand[l];}//for l
            }//for k
        }//for j
    }//for i

    //�p��pgn����
	Rtn=PgnOption(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue,
	               StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
	printf("rtn = %lf \n",Rtn);




if(1){//==============================�p��Greeks
    //for(i=0;i<5;i++)
    for(i=0;i<StockNum;i++)
    {

        printf("======%ld====\n",i);
		//�p��delta
		delta = PgnDelta(i,SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
		printf("PGN Delta = %f \n",delta);


		//�p��gamma
		gamma = PgnGamma(i,SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
		printf("PGN Gamma = %f \n",gamma);

		//�p��vega
		vega = PgnVega(i,SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
		printf("PGN Vega = %f \n",vega);

    }

    //�p��Pgn��Theta
    theta = PgnTheta(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
    printf("PGN Theta = %f \n",theta);

    //�p��Pgn��Rho
    rho = PgnRho(SimuTimes, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue, StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
    printf("PGN Rho = %f \n",rho);
}//==============================�p��Greeks


    for(i=0; i<SimuTimes; i++){
        for(j=0; j<TIMESPLIT; j++)   free(CorrNormRand[i][j]);
        free(CorrNormRand[i]);
    }
    free(CorrNormRand);


if(0){//==============================���Ħ���
    RandSeed = -1*(unsigned)time(NULL);
    FILE* fp1=fopen("Converge.txt","w");
    long ContTime=0;
    for(ContTime=1000;ContTime<=100000;ContTime+=1000){
            //�t�m�`�A�üƪ��Ŷ�
	CorrNormRand=(double***)malloc(ContTime*sizeof(double**));
    for(i=0; i<ContTime; i++){
        CorrNormRand[i]=(double**)malloc((1+TIMESPLIT)*sizeof(double*));
        for(j=0;j<1+TIMESPLIT;j++){
            CorrNormRand[i][j]=(double*)malloc(StockNum*sizeof(double));
            for(k=0;k<StockNum;k++) {CorrNormRand[i][j][k]=0;}
        }
    }

    //�����`�A�ü�
    for(i=0; i<ContTime; i++){
        for(j=0; j<TIMESPLIT+1; j++){
            for(k=0; k<StockNum; k++)	{NormRand[k]=StdNormal_Rand(&RandSeed);}//for k
            for(k=0; k<StockNum; k++){
                for(l=0; l<=k; l++)		{CorrNormRand[i][j][k] += LL[k][l]*NormRand[l];}//for l
            }//for k
        }//for j
    }//for i


        Rtn=PgnOption(ContTime, TrdDay, CrtDay, GRate, PRate, RfRate, FaceValue,
	               StockInitPx, StockInitPx, StockVol, dt, StockNum,CorrNormRand);
        printf("rtn = %lf \n",Rtn);
        fprintf(fp1,"%lf\n",Rtn);

    for(i=0; i<ContTime; i++){
        for(j=0; j<TIMESPLIT; j++)   free(CorrNormRand[i][j]);
        free(CorrNormRand[i]);
    }
    free(CorrNormRand);
    }

    fclose(fp1);
}//==============================���Ħ���

	system("PAUSE");
	return 0;
}

