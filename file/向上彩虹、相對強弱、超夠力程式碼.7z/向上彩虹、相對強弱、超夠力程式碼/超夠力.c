#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

/*Constants For Uniform_Rand function*/
#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)

#define MAXSTOCKNUM 10
#define MAXSTOCKDAY 500
#define WORKDAY 250.0
#define CLDRDAY 365.0
#define TimeSplit 1.0//���δ���

/* Generate Uniform Random variables*/
double Uniform_Rand(long *idum)
{
	int j = 0;
	long k = 0;
	double temp = 0;
	static long iy=0;
	static long iv[NTAB];

	if (0 >= *idum || !iy){
		if (1 > -(*idum)) *idum=1;
		else *idum = -(*idum);
			for (j=NTAB+7; 0<=j; j--){
				k = (*idum) / IQ;
				*idum = IA * (*idum-k*IQ) - IR * k;
				if (0 > *idum) *idum += IM;
				if (j < NTAB) iv[j] = *idum;
			}
		iy = iv[0];
	}
	k = (*idum) / IQ;
	*idum = IA * (*idum-k*IQ) - IR * k;
	if (0 > *idum) *idum += IM;
	j = iy / NDIV;
	iy = iv[j];
	iv[j] = *idum;
	if ((temp=AM*iy) > RNMX) return (double)RNMX;
	else return temp;
}//End of Uniform_Rand



/*Generate Standard Normal Random variables
  Returns a normally distributed deviate with zero mean and unit variance,
  using Uniform_gen(idum) as the source of uniform deviates.
*/
double StdNormal_Rand(long *idum)
{
//    float gasdev(long *idum);
//    float Uniform_Rnd(long *idum);
    static int iset = 0;
    static double gset = 0;
    double fac=0, rsq=0, v1=0, v2=0;

    if (0>*idum) iset = 0;
    if (0 == iset ){
        do{
            v1 = 2.0 * Uniform_Rand(idum) - 1.0;
            v2 = 2.0 * Uniform_Rand(idum) - 1.0;
            rsq = v1*v1 + v2*v2;
        }while (1.0 <= rsq || 0.0 == rsq);
        fac = sqrt(-2.0 * log(rsq) / rsq);
        gset = v1 * fac;
        iset = 1;
        return v2 * fac;
    }
    else{
        iset = 0;
        return gset;
    }
}//end of StdNormal_Rnd


void Cholesky(double Corr[][MAXSTOCKNUM],double LL[][MAXSTOCKNUM],int StockNum )
{
    int i=0,j=0,k=0;
    for(i=0; i<StockNum; i++){
        double sum1=0;
        for(j=0; j<i; j++)  {sum1 += LL[i][j]*LL[i][j];}
        LL[i][i] = sqrt(Corr[i][i] - sum1);
        for(j=i+1; j<StockNum; j++){
            double sum2 = 0;
            for(k=0; k<i; k++)  {sum2 += LL[j][k]*LL[i][k];}
            LL[j][i] = (Corr[j][i]-sum2) / LL[i][i];
        }
    }
}


//�z�׭�
double RainbowValue(long SimuTimes, double TotalCldDay, double TrdDay, double CldDay,
            double HStkRatio,double LStkRatio,double FaceValue,double RfRate,double Interest,
            double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
            double StockVol[MAXSTOCKNUM], double dt, int StockNum, double*** CorrNormRand )
{
	long i=0,j=0,k=0;
	double SimuPx[MAXSTOCKNUM]={0}, RainbowRtnSum=0;
    for(i=0; i<SimuTimes; i++){
        double MinPayoff=0, RainbowRtn=0;
        for(j=0; j<StockNum; j++){ SimuPx[j]=StockPx[j]; }//�_�l�ѻ�
        for(j=0; j<TimeSplit; j++){//�����ѻ�
            for(k=0; k<StockNum; k++){
                SimuPx[k]=SimuPx[k]*exp((RfRate-0.5*StockVol[k]*StockVol[k])*dt+StockVol[k]*CorrNormRand[i][j][k]*sqrt(dt));
            }
        }//end of simu stock px
        //printf("SimuPx=%f\n",SimuPx[0]);
        MinPayoff=SimuPx[0]/StockInitPx[0]-1;

        for(k=1; k<StockNum; k++){//�p��̧C���S
            double tmprtn=(SimuPx[k]/StockInitPx[k])-1;
            if(MinPayoff>tmprtn){ MinPayoff=tmprtn;  }
        }
        //printf("Mp=%f\n",MinPayoff);
        double trtn=1+HStkRatio*MinPayoff;
        RainbowRtn=(trtn>=LStkRatio)?trtn:LStkRatio;
        RainbowRtnSum+=RainbowRtn;
    }//end of SimuTimes
    RainbowRtnSum/=(double)SimuTimes;
    RainbowRtnSum=FaceValue*(RainbowRtnSum)*pow(1+RfRate,-(CldDay/CLDRDAY));
	return RainbowRtnSum;
}




//�p���@�Ӫ�Delta
//k�N����k�ӼЪ� k=0,1,2,3,4
double RainbowDelta(int k, long SimuTimes, double TotalCldDay, double TrdDay, double CldDay,
            double HStkRatio,double LStkRatio,double FaceValue,double RfRate,double Interest,
            double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
            double StockVol[MAXSTOCKNUM], double dt, int StockNum, double*** CorrNormRand )
{
    double SNew[MAXSTOCKNUM]={0}, deltas=0.001, UPx=0, DPx=0;
    int i=0;

    if(1>TrdDay){return 0;};
    for(i=0; i<StockNum; i++) {SNew[i]=StockPx[i];}

	SNew[k]=StockPx[k]+deltas;
	UPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, SNew, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
	SNew[k]=StockPx[k]-deltas;
	DPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, SNew, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
	return (UPx-DPx)/(2*deltas);
}


//�p���@�Ӫ�Gamma
//k�N����k�ӼЪ� k=0,1,2,3,4
double RainbowGamma(int k, long SimuTimes, double TotalCldDay, double TrdDay, double CldDay,
            double HStkRatio,double LStkRatio,double FaceValue,double RfRate,double Interest,
            double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
            double StockVol[MAXSTOCKNUM], double dt, int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double SNew[MAXSTOCKNUM]={0}, deltas=0.001, UPx=0, DPx=0, Px=0;
    int i=0;
    for(i=0; i<StockNum; i++) {SNew[i]=StockPx[i];}

    Px=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, SNew, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
	SNew[k]=StockPx[k]+deltas;
	UPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, SNew, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
	SNew[k]=StockPx[k]-deltas;
	DPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, SNew, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
	return ((UPx-Px)/deltas-(Px-DPx)/deltas)/deltas;
}


//�p���@�Ӫ�Vega
double RainbowVega(int k, long SimuTimes, double TotalCldDay, double TrdDay, double CldDay,
            double HStkRatio,double LStkRatio,double FaceValue,double RfRate,double Interest,
            double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
            double StockVol[MAXSTOCKNUM], double dt, int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double SVolNew[MAXSTOCKNUM]={0}, deltav=0.01, UPx=0, DPx=0;
    int i=0;
    for(i=0;i<StockNum;i++) {SVolNew[i]=StockVol[i];}

	SVolNew[k]=StockVol[k]+deltav;
	UPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, SVolNew,
                    dt, StockNum, CorrNormRand);
	if(0.01>=StockVol[k]){
        double Tmp=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
        return (UPx-Tmp)/0.01;
    }
	SVolNew[k]=StockVol[k]-deltav;
	DPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, SVolNew,
                    dt, StockNum, CorrNormRand);
	return (UPx-DPx)/(2*deltav);
}


//�p���@�Ӫ�Theta
double RainbowTheta(long SimuTimes, double TotalCldDay, double TrdDay, double CldDay,
            double HStkRatio,double LStkRatio,double FaceValue,double RfRate,double Interest,
            double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
            double StockVol[MAXSTOCKNUM], double dt, int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double UPx=0, DPx=0;

	UPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay+1, CldDay+1, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
	DPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay-1, CldDay-1, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
	return (DPx-UPx)/2;
}


//�p���@�Ӫ�Rho
double RainbowRho(long SimuTimes, double TotalCldDay, double TrdDay, double CldDay,
            double HStkRatio,double LStkRatio,double FaceValue,double RfRate,double Interest,
            double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
            double StockVol[MAXSTOCKNUM], double dt, int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double UPx=0, DPx=0, DeltaR=0.0001;
	UPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate+DeltaR, Interest, StockPx, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
    if(0.0001>=RfRate){
        double tmp=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
        return (UPx-tmp)/DeltaR;
    }
	DPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate-DeltaR, Interest, StockPx, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
    /*
    printf("%ld %f %f %f \n",SimuTimes, TotalCldDay, TrdDay, CldDay);
    printf("%f %f %f %f \n",HStkRatio, LStkRatio, FaceValue,RfRate);
    printf("%f %f %d \n",Interest,dt,StockNum);
    for(i=0;i<StockNum;i++){printf("%f %f %f \n",StockInitPx[i],StockPx[i],StockVol[i]);}
    */
	return (UPx-DPx)/2.0;
}






//�p�� 1 Delta risk
double RainbowOneDeltaRisk( long SimuTimes, double TotalCldDay, double TrdDay, double CldDay,
            double HStkRatio,double LStkRatio,double FaceValue,double RfRate,double Interest,
            double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
            double StockVol[MAXSTOCKNUM], double dt, int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double SNew[MAXSTOCKNUM]={0}, deltas=0.01, UPx=0, DPx=0, AvgPx=0;
    int i=0;
    for(i=0; i<StockNum; i++) {SNew[i]=StockPx[i]*(1+deltas);AvgPx+=SNew[i];}
    AvgPx/=StockNum;
	UPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, SNew, StockInitPx, StockVol, dt, StockNum, CorrNormRand);
	for(i=0; i<StockNum; i++) {SNew[i]=StockPx[i]*(1-deltas);}
	DPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, SNew, StockInitPx, StockVol, dt, StockNum, CorrNormRand);
	return (UPx-DPx)/(2*deltas);
	return (UPx-DPx)/AvgPx;
}





//�p�� Rainbow One Vega Risk
double RainbowOneVegaRisk(long SimuTimes, double TotalCldDay, double TrdDay, double CldDay,
            double HStkRatio,double LStkRatio,double FaceValue,double RfRate,double Interest,
            double StockPx[MAXSTOCKNUM], double StockInitPx[MAXSTOCKNUM],
            double StockVol[MAXSTOCKNUM], double dt, int StockNum, double*** CorrNormRand )
{
    if(1>TrdDay){ return 0; };
    double SVolNew[MAXSTOCKNUM]={0}, deltav=0.01, UPx=0, DPx=0;
    int i=0;
    for(i=0;i<StockNum;i++) {SVolNew[i]=StockVol[i]+deltav;}
	UPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, SVolNew, dt, StockNum, CorrNormRand);
	for(i=0;i<StockNum;i++) {
		if(0.01>=StockVol[i]){SVolNew[i]=StockVol[i];}
		else{SVolNew[i]=StockVol[i]-deltav;}
	}
	DPx=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, SVolNew, dt, StockNum, CorrNormRand);
	return (UPx-DPx)/(2*deltav);
}





int main()
{
    double PgnVal=0, dt=0;
	long i=0, j=0, k=0, l=0, StockNum=3;
    //�ݭnŪ�ɪ��Ѽ�
    long SimuTimes=0, RandSeed=0;
    int TotalCldDay, TrdDay=0, CldDay=0;

    double HStkRatio=0,LStkRatio=0,FaceValue=0, RfRate=0, Interest=0;
    double StockInitPx[MAXSTOCKNUM]={0},StockPx[MAXSTOCKNUM]={0},StockVol[MAXSTOCKNUM]={0};
    double Corr[MAXSTOCKNUM][MAXSTOCKNUM]={0}, LL[MAXSTOCKNUM][MAXSTOCKNUM]={0};
    double*** CorrNormRand,NormRand[MAXSTOCKNUM]={0};
    i=9;
    //�q�ɮ�Ū�Ѽ�
    FILE* fp=fopen("PGNData.txt","r");
    fscanf(fp,"%ld",&SimuTimes);//��������
    fscanf(fp,"%d",&TotalCldDay);//�ӧ@�Ѵ�
    fscanf(fp,"%d",&TrdDay);//�����
    fscanf(fp,"%d",&CldDay);//����
    fscanf(fp,"%lf",&HStkRatio);//�̧C�ѻP���T
    fscanf(fp,"%lf",&LStkRatio);//�����O���v
    fscanf(fp,"%lf",&FaceValue);//����
    fscanf(fp,"%lf",&RfRate);//�L�I�Q�v
    for(i=0; i<StockNum; i++){ fscanf(fp,"%lf",&StockInitPx[i]);}//�_�l�ѻ�
    for(i=0; i<StockNum; i++){ fscanf(fp,"%lf",&StockPx[i]);}//�ثe�ѻ�
    for(i=0; i<StockNum; i++){fscanf(fp,"%lf",&StockVol[i]);}//�i�ʲv
    for(i=0; i<StockNum; i++){
        for(j=0; j<StockNum; j++){fscanf(fp,"%lf",&Corr[i][j]);}
    }//�����Y��
    fclose(fp);

    Cholesky(Corr,LL,StockNum);
	dt = TrdDay/TimeSplit/(double)WORKDAY;

//������
//for(m=0;m<10;m++){

    //�t�m�`�A�üƪ��Ŷ�
	CorrNormRand=(double***)malloc(SimuTimes*sizeof(double**));
    for(i=0; i<SimuTimes; i++){
        CorrNormRand[i]=(double**)malloc((1+TimeSplit)*sizeof(double*));
        for(j=0;j<(1+TimeSplit);j++){
            CorrNormRand[i][j]=(double*)malloc(StockNum*sizeof(double));
            for(k=0;k<StockNum;k++) {CorrNormRand[i][j][k]=0;}
        }
    }

    //�����`�A�ü�
    RandSeed = -1*(unsigned)time(NULL);
    for(i=0; i<SimuTimes; i++){
        for(j=0; j<(1+TimeSplit); j++){
            for(k=0; k<StockNum; k++)	{NormRand[k]=StdNormal_Rand(&RandSeed);};//for k
            for(k=0; k<StockNum; k++){
                for(l=0; l<=k; l++)		{CorrNormRand[i][j][k] += LL[k][l]*NormRand[l];}//for l
            }//for k
        }//for j
    }//for i

    //�p��pgn����
	PgnVal=RainbowValue(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, StockVol,
                    dt, StockNum, CorrNormRand);
	printf("PgnValue = %0.0lf \n",PgnVal);

    //GREEKS
    double delta[MAXSTOCKNUM]={0},gamma[MAXSTOCKNUM]={0},vega[MAXSTOCKNUM]={0},rho=0,theta=0;
    for(i=0; i<StockNum; i++){
        delta[i] = RainbowDelta(i, SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, StockVol, dt, StockNum, CorrNormRand);
        gamma[i] = RainbowGamma(i, SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, StockVol, dt, StockNum, CorrNormRand);
        vega[i] = RainbowVega(i, SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, StockVol, dt, StockNum, CorrNormRand);
        printf("delta[%ld]=%0.0f \t gamma[%ld]=%0.0f   \t vega[%ld]=%0.0f\n",i,delta[i],i,gamma[i],i,vega[i]);
    }

    theta = RainbowTheta(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, StockVol,dt, StockNum, CorrNormRand);

    rho = RainbowRho(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockPx, StockInitPx, StockVol,dt, StockNum, CorrNormRand);
    double ODR=0,OVR=0;
    ODR=RainbowOneDeltaRisk(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockInitPx, StockInitPx, StockVol,dt, StockNum, CorrNormRand);
    OVR=RainbowOneVegaRisk(SimuTimes, TotalCldDay, TrdDay, CldDay, HStkRatio, LStkRatio, FaceValue,
                    RfRate, Interest, StockInitPx, StockInitPx, StockVol,dt, StockNum, CorrNormRand);

    //printf("theta=%0.0f \t rho=%0.0f \t ODR=%0.0f \t OVR=%0.0f \n",theta,rho,ODR,OVR);
    printf("theta=%0.0f \t rho=%0.0f \t \n",theta,rho);

    //free memory
    for(i=0; i<SimuTimes; i++){
        for(j=0; j<(1+TimeSplit); j++)   free(CorrNormRand[i][j]);
        free(CorrNormRand[i]);
    }
    free(CorrNormRand);

//}//�����ĥ�

    system("PAUSE");
    return 0;
}
